# src/lib/agents/critic-agent.ts

```typescript
import { z } from 'zod'
import { Source } from '@/types'
import { llmService } from '../services/llm-service'
import { appConfig } from '../config'
import { truncateContext, sanitizeQueryForPrompt, JSON_OUTPUT_REQUIREMENTS } from '../prompt-utils'
import type { KBContext } from './agent-context'

export interface ValidationResult {
  isValid: boolean
  confidence: number
  issues: string[]
  suggestions: string[]
  faithfulnessScore: number
  relevanceScore: number
}

const validationResultSchema: z.ZodType<ValidationResult> = z.object({
  isValid: z.boolean(),
  confidence: z.number().min(0).max(1),
  issues: z.array(z.string()),
  suggestions: z.array(z.string()),
  faithfulnessScore: z.number().min(0).max(1),
  relevanceScore: z.number().min(0).max(1)
})

export class CriticAgent {
  /**
   * Validate response with KB-calibrated thresholds.
   * When KB context is provided, adjusts validation thresholds based on
   * content type (technical docs have higher faithfulness expectations).
   */
  async validateResponse(
    query: string,
    response: string,
    sources: Source[],
    kb?: KBContext
  ): Promise<ValidationResult> {
    // Limit and sort sources for efficient, high-signal validation context
    const limitedSources = [...sources]
      .sort((a, b) => (b.azureScore ?? b.relevanceScore) - (a.azureScore ?? a.relevanceScore))
      .slice(0, appConfig.critic.maxSources)

    const rawContext = limitedSources
      .map((s, i) => `[${i + 1}] ${s.content}`)
      .join('\n\n')

    const contextSnippets = truncateContext(rawContext, appConfig.truncation.criticMaxTokens, {
      notice: '[Context truncated for validation]'
    })

    // Build KB-aware validation guidelines
    let kbGuidelines = ''
    if (kb) {
      const isTechnical = kb.contentTypes.technical > 0.5 || kb.contentTypes.code > 0.5
      const faithfulnessThreshold = isTechnical ? 0.8 : 0.7

      kbGuidelines = `

Knowledge Base Context:
- Content type: ${kb.contentTypes.code > 0.5 ? 'code-heavy' : kb.contentTypes.technical > 0.5 ? 'technical documentation' : 'prose/documentation'}
- Validation standards: ${isTechnical ? 'High precision required for technical content' : 'Standard validation for prose'}

Calibrated Thresholds:
- Faithfulness threshold: ${faithfulnessThreshold} (${isTechnical ? 'higher for technical content' : 'standard'})
- Technical content requires exact terminology and precise citations
- Prose content allows more paraphrasing while maintaining faithfulness`
    }

    const systemPrompt = `You are a fact-checking expert. Validate AI responses against source documents.

Evaluation criteria:
1. FAITHFULNESS: Is the response supported by the sources? No hallucinations?
2. RELEVANCE: Does the response actually answer the question?
3. ACCURACY: Are facts correctly stated?
4. CITATIONS: Are sources properly referenced?

Identify issues:
- Unsupported claims not in sources
- Incorrect facts
- Missing important information from sources
- Irrelevant content
${kbGuidelines}

Respond with JSON:
{
  "isValid": boolean,
  "confidence": 0.0-1.0,
  "issues": ["list of problems"],
  "suggestions": ["how to improve"],
  "faithfulnessScore": 0.0-1.0,
  "relevanceScore": 0.0-1.0
}`

    try {
      const prompt = `${systemPrompt}
 ${JSON_OUTPUT_REQUIREMENTS}

 Source documents:
 ${contextSnippets}

 User question: ${sanitizeQueryForPrompt(query)}

 AI response to validate:
 ${response}

 Provide validation as JSON:`

       return await llmService.generateJson(prompt, validationResultSchema, {
         maxTokens: appConfig.truncation.criticMaxTokens,
         temperature: appConfig.temps.critic
       })
    } catch (error) {
      console.warn('LLM validation failed, using fallback:', error)
    }

    return this.fallbackValidation(query, response, sources, kb)
  }

  private fallbackValidation(
    query: string,
    response: string,
    sources: Source[],
    kb?: KBContext
  ): ValidationResult {
    // KB-aware threshold calibration
    const isTechnical = kb && (kb.contentTypes.technical > 0.5 || kb.contentTypes.code > 0.5)
    const faithfulnessThreshold = isTechnical ? 0.7 : 0.6 // Higher bar for technical content
    const relevanceThreshold = 0.5
    const lowerResponse = response.toLowerCase()
    const lowerQuery = query.toLowerCase()

    const hasCitations = /\[[\d,\s]+\]/.test(response)

    const queryWords = lowerQuery.split(/\s+/).filter(w => w.length > 3)
    const matchingWords = queryWords.filter(word => lowerResponse.includes(word))
    const relevanceScore = matchingWords.length / Math.max(queryWords.length, 1)

    const sourceWords = new Set(
      sources.flatMap(s => s.content.toLowerCase().split(/\s+/))
    )
    const responseWords = lowerResponse.split(/\s+/).filter(w => w.length > 4)
    const supportedWords = responseWords.filter(word => sourceWords.has(word))
    const faithfulnessScore = supportedWords.length / Math.max(responseWords.length, 1)

    const issues: string[] = []
    const suggestions: string[] = []

    if (!hasCitations) {
      issues.push('Response lacks source citations')
      suggestions.push('Add citations to reference sources')
    }

    if (faithfulnessScore < faithfulnessThreshold) {
      issues.push(isTechnical
        ? 'Response may contain unsupported claims (technical content requires high precision)'
        : 'Response may contain unsupported claims')
      suggestions.push('Ensure all facts are from provided sources')
    }

    if (relevanceScore < relevanceThreshold) {
      issues.push('Response may not fully address the query')
      suggestions.push('Focus response more directly on the question')
    }

    const isValid = issues.length === 0 && faithfulnessScore > faithfulnessThreshold && relevanceScore > relevanceThreshold

    return {
      isValid,
      confidence: isValid ? 0.7 : 0.5,
      issues,
      suggestions,
      faithfulnessScore: Math.min(faithfulnessScore, 1.0),
      relevanceScore: Math.min(relevanceScore, 1.0)
    }
  }
}

```
