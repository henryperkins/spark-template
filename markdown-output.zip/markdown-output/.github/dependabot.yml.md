# .github/dependabot.yml

```yaml
version: 2
updates:
  - package-ecosystem: "npm"
    directory: "/"
    schedule:
      interval: "daily"

  - package-ecosystem: "devcontainers"
    directory: "/"
    schedule:
      interval: "weekly"

```
