# .github/copilot-instructions.md

```markdown
# Spark Template Copilot Guide
- **Architecture**: Multi-agent RAG orchestrated by src/lib/agents/orchestrator.ts; UI drives it through src/components/QueryInterface.tsx and AgentWorkflowVisualizer.
- **Agent Orchestrator**: Add new steps with executeStep(...) to keep telemetry, budgets, and UI workflow in sync with tokenTracker/telemetry hooks.
- **Shared Context**: Always build KB-aware data via buildKBContext + createQueryExecutionContext so new agents receive embedding coverage, budgets, and warning collectors.
- **Token & Cost Tracking**: Route all LLM calls through src/lib/services/llm-service.ts to populate tokenTracker and recordLLMCall; do not call azureServiceManager directly from UI/controller code.
- **Document Pipeline**: Ingestion flows DocumentUpload → intelligentChunkDocument → azureServiceManager.processDocumentWithAzure; when mutating documents call cacheManager.invalidateDocument + invalidateByPrefix('query-expansion').
- **Chunking Decisions**: DocumentAnalyzerAgent chooses strategies; respect ChunkingStrategy return values if introducing new ingestion sources.
- **Retrieval Logic**: findRelevantChunks() caches results under rag-query keys and handles Azure fallback; pass onAzureFallback handlers so UI can surface degraded mode.
- **Cache Manager Usage**: cacheManager auto-selects TTL by key prefix; reuse prefixes doc:, query-expansion, rag-query to benefit from adaptiveTTL and invalidation tooling.
- **Persistent Storage**: use useStorage/useKV from src/hooks/use-kv.ts—this auto-selects Cloudflare KV via createCloudflareKV and falls back to localStorage.
- **Namespace Conventions**: Document chunks should carry namespace metadata to align with azureServiceManager.getNamespaceId() filtering.
- **App Config**: Fetch runtime settings via appConfig (src/lib/config.ts); new env knobs must be VITE_* so both Vite and worker exposure stay consistent.
- **Runtime Detection**: runtime.* helpers map Cloudflare vs local behavior; prefer runtime.getStorageMode() and runtime.isAzureConfigured() instead of window checks.
- **LLM Access**: runtime-context.ts exposes runtime.llm and telemetry sinks; for lightweight prompts use that provider or LLMService to inherit dev stubs (/api/llm).
- **Telemetry**: Send agent step updates through telemetry.trackAgentStep; Worker-side /api/telemetry expects Authorization per worker/index.ts CORS rules.
- **Worker Endpoints**: worker/index.ts gates /api/kv, /api/telemetry, /api/llm, /api/azure-search, /api/logs—preserve CORS headers and Authorization checks when adding routes.
- **Secrets Checklist**: KV_API_KEY, LOGS_API_KEY, AZURE_API_KEY, OPENAI_API_KEY set via wrangler secret; mirror client token in localStorage for dev per cloudflare-kv adapter.
- **UI Conventions**: src/components/ui hosts shadcn-style primitives; compose feature components with cn(...) helper and Tailwind tokens from styles/tokens.css.
- **Navigation Structure**: ResponsiveNavigation expects tabs {value,label,icon,content}; keep Brain/FileText icon sizing via NAV_ICON_SIZE pattern in App.tsx.
- **Prompt Hygiene**: sanitize user prompts with sanitizeQueryForPrompt and append JSON_OUTPUT_REQUIREMENTS when enforcing structured outputs.
- **Agent Workflow Data**: AgentWorkflowStep requires agent/action/status/duration; if you emit degraded states, update AgentWorkflowVisualizer and Observability dashboards together.
- **Testing**: Run npm run test (Vitest) for agent logic; existing suites assert token caps (test/react-agent.test.ts) and KB context builders (test/agent-context.test.ts).
- **Dev Builds**: npm run dev for Vite UI, npm run cf:dev to run worker after building dist, npm run cf:deploy* commands wrap wrangler deploy flows.
- **Smoke Checks**: Follow docs/SMOKE-TEST.md after deployments to validate KV auth, LLM proxy behavior, telemetry, and cache hit rates.
- **Tsconfig Gotchas**: bundler moduleResolution and allowImportingTsExtensions mean keep explicit extensions on relative imports; @/* alias resolves to src.
- **Observability**: tokenTracker + errorTracking persist to KV; expose new metrics via queryHistoryService so SearchDebugger and ScalingDashboard stay coherent.
- **Docs Reference**: For deeper agent architecture and context flow see docs/ARCHITECTURE.md and docs/context-architecture.md—align new features with those contracts.
- **Error Reporting**: Use errorTracking.record on caught failures so worker logs and analytics match UI alerts; executeStep() already wraps this—reuse that helper.

```
