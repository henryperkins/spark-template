# .roo/mcp.json

```json
{
  "mcpServers": {
    "exa": {
      "command": "npx",
      "args": [
        "-y",
        "exa-mcp-server"
      ],
      "env": {
        "EXA_API_KEY": "572576b1-103b-4541-99b0-c95ce37339e7"
      }
    }
  }
}
```
